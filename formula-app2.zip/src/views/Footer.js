import React from 'react';



class Footer extends React.Component {

    render() {
       return (

            <div className="row footer">
                <div className="col s12">
                    <p>Designed and Coded by Vladimir Cordas 2019. Based on ERGAST API.</p>
                </div>
            </div>
        );
    }
}


export default Footer;