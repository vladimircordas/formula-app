import React from 'react';
import * as $ from 'jquery';
import { racePosition } from '../functions/racePosition';

import Flag from 'react-world-flags'
import { flags } from '../functions/flags';


export class TeamResults extends React.Component {
    constructor() {
        super();
        this.state = {
            results: [],
            loading: true,
            search: ""
        }
        this.getResults = this.getResults.bind(this);
    }

    componentDidMount() {
        this.getResults();
    }

    getResults() {
        const id = this.props.teamid
        var url = `http://ergast.com/api/f1/2013/constructors/${id}/results.json`;
        $.get(url, (data) => {
            this.setState({
                results: data,
                loading: false
            });
        });
    }

    updateSearch(event) {
        this.setState({ search: event.target.value.substr(0, 20) });
    }

    render() {
        if (this.state.loading === true) {
            return <h1>Loading...</h1>
        }
        var results = this.state.results.MRData.RaceTable.Races;
        var filteredResults = results.filter(
            (result) => {
                return result.raceName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1;
            }
        );
        //console.log(results);
        return (
            <table>
                <thead>
                    <tr>
                        <th colSpan='2'>Team Results</th>
                        <th colSpan='3'>
                            <input type="text"
                                value={this.state.search}
                                onChange={this.updateSearch.bind(this)}
                            />

                        </th>
                    </tr>
                    <tr>
                        <th>Round</th>
                        <th>Grand Prix</th>
                        <th>{results[0].Results[0].Driver.familyName}</th>
                        <th>{results[0].Results[1].Driver.familyName}</th>
                        <th>Points</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredResults.map((result, i) => <Results resultData={result} key={i} />)}
                </tbody>
            </table>
        )

    }
}

class Results extends React.Component {
    render() {

        const { resultData } = this.props;

        const driver1 = resultData.Results[0].position;
        const driver2 = resultData.Results[1].position;
        const nation = resultData.Circuit.Location.country;
        return (
            <tr>
                <td>{resultData.round}</td>
                <td>
                    <div className="waves-effect waves-light btn-flat no-coursor flagLeft">
                        <div className="flagHolder">
                            <Flag code={`${flags(nation)}`} height='20' width='50' />
                        </div>
                        {resultData.raceName}
                    </div></td>
                <td className={`${racePosition(driver1)}`}>{resultData.Results[0].position}</td>
                <td className={`${racePosition(driver2)}`}>{resultData.Results[1].position}</td>
                <td>


                    {resultData.Results[0].points}

                </td>
            </tr>
        )
    }
}

export default TeamResults;