export function driverImage(fname) {
  switch (fname) {
    case 'Vettel':
      return '../../images/drivers/Vettel.jpg';

    case 'Alonso':
      return '../../images/drivers/alonso.jpg';

    case 'Webber':
      return '../../images/drivers/webber.jpg';
      
    case 'Hamilton':
      return '../../images/drivers/hamilton.jpg';
        
    case 'Räikkönen':
      return '../../images/drivers/raikkonen.jpg';

    case 'Rosberg':
      return '../../images/drivers/rosberg.jpg';

    case 'Grosjean':
      return '../../images/drivers/grosjean.jpg';

    case 'Massa':
      return '../../images/drivers/massa.jpg';

    case 'Button':
      return '../../images/drivers/button.jpg';

    case 'Hülkenberg':
      return '../../images/drivers/hulkenberg.jpg';

    case 'Pérez':
      return '../../images/drivers/perez.jpg';
    
    case 'di Resta':
      return '../../images/drivers/di-resta.jpg';

    case 'Sutil':
      return '../../images/drivers/sutil.jpg';

    case 'Ricciardo':
      return '../../images/drivers/ricciardo.jpg';
  
    case 'Vergne':
      return '../../images/drivers/vergne.jpg';

    case 'Gutiérrez':
      return '../../images/drivers/gutierrez.jpg'

    case 'Bottas':
      return '../../images/drivers/bottas.jpg'
  
    case 'Maldonado':
      return '../../images/drivers/maldonado.jpg'
    
    case 'Bianchi':
      return '../../images/drivers/bianchi.jpg'
    
    case 'Pic':
      return '../../images/drivers/pic.jpg'

    case 'van der Garde':
      return '../../images/drivers/van-der-garde.jpg'

    case 'Kovalainen':
      return '../../images/drivers/kovalainen.jpg'

    case 'Chilton':
      return '../../images/drivers/chilton.jpg'
      
    default:
      return '../../images/drivers/default.jpg';
  }
}