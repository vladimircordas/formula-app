
import React, {Component} from 'react';
import { Router, Route, Switch } from "react-router-dom";
// import createBrowserHistory from 'history/createBrowserHistory';  history={createBrowserHistory}
import history from './history';
import Header from './views/Header'
import Home from './views/Home';
import Drivers from './views/Drivers';
import Teams from './views/Teams';
import Races from './views/Races';
import DriverDetails from './components/drivers/DriverDetails';
import TeamDetails from './components/teams/TeamDetails';
import RaceDetails from './components/races/RaceDetails';
import './App.css';


import NotFound from './views/NotFound';


import SelectYear from './components/SelectYear';

class App extends Component {
  constructor(){
    super();
    this.state = {
      selectedYear: 2013
    }
  }

  getSelectedYear = (year) =>{
    this.setState({
      selectedYear: year
    });
  }

  render() {
    var year = this.state.selectedYear;
    console.log('app '+this.state.selectedYear)
    return (
    <div>
      <Router history={history}>
        <SelectYear getYear={this.getSelectedYear} year={year} />
        <Header  year={year} />
        <div className="mainBody">
          <Switch>
            <Route exact path='/' component={()=> <Home year={year} />} />

            <Route exact path='/drivers/:year' component={() => <Drivers year={year} />} />
            <Route exact path='/drivers/:driver/:year' component={(props) => <DriverDetails {...props} year={year} />} />
            
            <Route exact path='/teams/:year' component={() => <Teams year={year} />} />
            <Route exact path='/teams/:team/:year' component={(props) => <TeamDetails {...props} year={year} />} />
            
            <Route exact path='/races/:year' component={() => <Races year={year} />} />
            <Route exact path='/races/:race/:year' component={(props) => <RaceDetails {...props} year={year} />} />
            
            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
    </div>
  );
}
}

export default App;