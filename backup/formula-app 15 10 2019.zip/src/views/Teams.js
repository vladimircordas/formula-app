import React from 'react';
import * as $ from 'jquery';
import { Link } from 'react-router-dom';
import Team from '../components/teams/Team';



class Teams extends React.Component {
    constructor() {
        super();

        this.state = {
            teams: [],
            loading: true,
            search: ""
        }
        this.getTeams = this.getTeams.bind(this);
    }

    componentDidMount() {
        this.getTeams();
    }

    getTeams() {
        var url = 'http://ergast.com/api/f1/2013/constructorStandings.json';
        $.get(url, (data) => {
            //    console.log(data);
            this.setState({
                teams: data,
                loading: false
            });
        });
    }

    updateSearch(event) {
        this.setState({ search: event.target.value.substr(0, 20) });
    }

    render() {
        if (this.state.loading === true) {
            return (
                <div>
                    <div className="loading"></div>
                </div>
            )
        }
        var teams = this.state.teams.MRData.StandingsTable.StandingsLists[0].ConstructorStandings;
        var filteredResults = teams.filter(
            
            (team) => {
                return team.Constructor.name.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1;
            }
        );


        return (
            <div>
                <div className="row">
                    <div className="col s12">
                        <div className='breadCrumbsHolder'>
                            <Link className="breadcrumb" to="/">Home</Link>
                            <span className="breadcrumb">Teams</span>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s12">
                        <table>
                            <thead>
                                <tr>
                                    <th colSpan='2'>Constructor Championship Standings - {this.state.teams.MRData.StandingsTable.season}</th>
                                    <th colSpan='2'>
                                        <div className="input-field">
                                            <input type="text"
                                                id="search_bar"
                                                value={this.state.search}
                                                onChange={this.updateSearch.bind(this)}
                                            />
                                            <label htmlFor="search_bar"><i className="material-icons">search</i></label >
                                        </div>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Position</th>
                                    <th>Team</th>
                                    <th>Details</th>
                                    <th>Points</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredResults.map((team, i) => <Team teamData={team} key={i} />)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        )
    }
}


export default Teams;