import React from 'react';
import * as $ from 'jquery';
import { Link } from 'react-router-dom';

import Race from '../components/races/Race';

class Races extends React.Component {
    constructor() {
        super();

        this.state = {
            races: [],
            loading: true,
            search: "",
            year: this.getYearFromWlocation()
        }
    }

    componentDidMount() {
        this.getRaces();
    }

    getYearFromWlocation(){
        var parts = window.location.href.split('/');
        var lastSegment = parts.pop() || parts.pop();

        return lastSegment;
    }

    getRaces = () => {
        var year = this.state.year;
        var url = `http://ergast.com/api/f1/${year}/results/1.json`;
        $.get(url, (data) => {
            this.setState({
                races: data,
                loading: false
            });
        });
    }

    updateSearch(event) {
        this.setState({ search: event.target.value.substr(0, 20) });
    }

    render() {
        if (this.state.loading === true) {
            return (
                <div className="wrapper">
                    <div className="loading"></div>
                </div>
            )
        }

        var races = this.state.races.MRData.RaceTable.Races;
        var filteredResults = races.filter(
            (race) => {
                return race.raceName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1 ||
                    race.Circuit.circuitName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1 ||
                    race.Results[0].Driver.givenName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1 ||
                    race.Results[0].Driver.familyName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1;
            }
        );
        return (
            <div className="wrapper">
                <div className="row">
                    <div className="col s12">
                        <Link className="breadcrumb" to="/">Home</Link>
                        <span className="breadcrumb" to="/">Races</span>
                    </div>
                </div>
                <div className="row">
                    <div className="col s12">
                        <table>
                            <thead>
                                <tr>
                                    <th colSpan='2'>Races calendar - {this.state.races.MRData.RaceTable.Races[0].season}</th>
                                    <th colSpan='3'>
                                        <div className="input-field">
                                            <input type="text"
                                                id="search_bar"
                                                value={this.state.search}
                                                onChange={this.updateSearch.bind(this)}
                                            />
                                            <label htmlFor="search_bar"><i className="material-icons">search</i></label >
                                        </div>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Race order</th>
                                    <th>Location</th>
                                    <th>Track name</th>
                                    <th>Date</th>
                                    <th>Winner</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredResults.map((race, i) => <Race raceData={race} key={i} />)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        )
    }
}



export default Races;