import React from 'react';

import SelectYear from '../components/SelectYear';

import ReactPlayer from 'react-player';



class Home extends React.Component {
    render() {


        return (

            <div className="wrapper">
                <h1 className="white-text text-darken-2 center-align">Welcome to Formula 1 Stats!</h1>
                <h4 className="white-text text-darken-2 center-align">Please select a year to proceed...</h4>
                <SelectYear />
                <div className="video-background">
                    <div className="video-overlay"></div>
                    <div className="video-foreground">
                        <ReactPlayer
                            url='https://www.youtube.com/watch?v=u1pPJj803Hk'
                            playing
                            youtube={{ playerVars: { showinfo: 1 } }}
                            loop={true}
                        />
                    </div>
                </div>
            </div>
        );
    }
}


export default Home;