
import React, {Component} from 'react';
import { Router, Route, Switch } from "react-router-dom";
// import createBrowserHistory from 'history/createBrowserHistory';  history={createBrowserHistory}
import history from './history';
import Header from './views/Header'
import Home from './views/Home';
import Drivers from './views/Drivers';
import Teams from './views/Teams';
import Races from './views/Races';
import DriverDetails from './components/drivers/DriverDetails';
import TeamDetails from './components/teams/TeamDetails';
import RaceDetails from './components/races/RaceDetails';
import './App.css';


import NotFound from './views/NotFound';


class App extends Component {
  render() {
    return (
    <div>
      <Router history={history}>
        <Header />
        <div className="mainBody">
          <Switch>
            <Route exact path='/' component={Home} />
            <Route exact path='/drivers/:year' component={Drivers} />
            <Route exact path='/teams/:year' component={Teams} />
            <Route exact path='/races/:year' component={Races} />
            <Route exact path='/drivers/:driver/:year' component={DriverDetails}/>
            <Route exact path='/teams/:team/:year' component={TeamDetails} />
            <Route exact path='/races/:race/:year' component={RaceDetails} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
    </div>
  );
}
}

export default App;