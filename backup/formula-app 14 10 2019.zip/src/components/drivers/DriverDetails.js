import React, { Component } from 'react';
import * as $ from 'jquery';
import { Link } from 'react-router-dom';

import DriverRaces from './DriverRaces';

// SLIKA VOZACA 

import { driverImage } from '../functions/driverImage';

export class DriverDetails extends Component {
    constructor() {
        super();

        this.state = {
            driver: [],
            loading: true,
            year: this.getYearFromWlocation()
        }


    }



    componentDidMount(){
        this.getDrivers();
        console.log(this.state.year);
        //console.log(this.state.year);
    }

    getYearFromWlocation = () => {
        var parts = window.location.href.split('/');
        var lastSegment = parts.pop() || parts.pop();

        return lastSegment;
    }

    getDrivers = () => {
        var year = this.state.year;
        const id = this.props.match.params.driver
        var url = `http://ergast.com/api/f1/${year}/drivers/${id}/driverStandings.json`;
        $.get(url, (data) => {
            // console.log(data.MRData.StandingsTable.StandingsLists[0].DriverStandings[0].Driver)
            this.setState({
                driver: data,
                loading: false
            });
        });

    }

    getDriversImages = () => {
        var year = this.state.year;
        const id = this.props.match.params.driver
        var url = `http://ergast.com/api/f1/${year}/drivers/${id}/driverStandings.json`;
        $.get(url, (data) => {
            // console.log(data.MRData.StandingsTable.StandingsLists[0].DriverStandings[0].Driver)
            this.setState({
                driver: data,
                loading: false
            });
        });

    }



    render() {
        if (this.state.loading === true) {
            return (
                <div className="wrapper">
                    <div className="loading"></div>
                </div>
            )
        }
        var driver = this.state.driver.MRData.StandingsTable.StandingsLists[0].DriverStandings[0];
        var fname = driver.Driver.familyName;
        var driversYear = '/drivers/' + this.state.year;
        

        return (
            <div className="driverDetailsWrapper">
                <div className="row">
                    <div className="col s12">
                        <div className='breadCrumbsHolder'>
                            <Link className="breadcrumb" to="/">Home</Link>
                            <Link className="breadcrumb" to={driversYear}>Drivers</Link>
                            <span className="breadcrumb">{driver.Driver.givenName} {driver.Driver.familyName}</span>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s4">
                        <div className="driverDetails">
                            <div className="card">
                                <div className="card-image">
                                    <img src={`${driverImage(fname)}`} alt="driver yeeeey" />
                                    <div className="card-content">
                                        <span>Name: <h5>{driver.Driver.givenName} {driver.Driver.familyName}</h5> </span>
                                        <p>Nationality: {driver.Driver.nationality}</p>
                                        <p>Team: {driver.Constructors[0].name}</p>
                                        <p>Birth: {driver.Driver.dateOfBirth}</p>
                                        <p><a href={`${driver.Driver.url}`} target="_blank" rel="noopener noreferrer">Biography: <i className="material-icons">open_in_new</i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s8">
                        <div className="driverRaces">
                            <DriverRaces driverid={this.props.match.params.driver} year={this.props.year} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default DriverDetails;
