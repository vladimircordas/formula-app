import React from 'react';
import * as $ from 'jquery';
import { Link } from 'react-router-dom';

import RaceResults from './RaceResults';
import RaceQualifiers from './RaceQualifiers';

import "materialize-css/dist/css/materialize.min.css";

// SLIKA VOZACA ""

import { circuitImage } from '../functions/circuitImage';

class RaceDetails extends React.Component {
    constructor() {
        super();

        this.state = {
            race: [],
            loading: true
        }
    }

    componentDidMount() {
        this.getRaces();

    }

    getRaces() {
        const id = this.props.match.params.race;
        var url = `http://ergast.com/api/f1/2013/circuits/${id}.json`;
        $.get(url, (data) => {
            this.setState({
                race: data,
                loading: false
            });
        });
    }

    render() {
        if (this.state.loading === true) {
            return (
                <div className="wrapper">
                    <div className="loading"></div>
                </div>
            )
        }
        var race = this.state.race.MRData.CircuitTable.Circuits[0];
        var circuit = race.circuitName;

        return (
            <div>
                <div className="row">
                    <div className="col s12">
                        <div className='breadCrumbsHolder'>
                            <Link className="breadcrumb" to="/">Home</Link>
                            <Link className="breadcrumb" to="/races">Races</Link>
                            <span className="breadcrumb">{race.circuitName}</span>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col s4">
                        <div className="driverDetails sticky">
                            <div className="driverDetails">
                                <div className="card">
                                    <div className="card-image">
                                        <img src={`${circuitImage(circuit)}`} alt="driver yeeeey" />
                                    </div>
                                    <div className="card-content">
                                        <h5>Name: {race.circuitName}</h5>
                                        <p>Country: {race.Location.country}</p>
                                        <p>Team: {race.Location.locality}</p>
                                        <p><a href={`${race.url}`} target="_blank" rel="noopener noreferrer">Full Report:  <i className="material-icons">open_in_new</i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col s8">
                        <div className="driverRaces">
                            <input type="checkbox" id="mobile-menu-checkbox" />
                            <div role="navigation" className="mobile-menu">
                                <RaceResults raceid={this.props.match.params.race} />
                            </div>
                            <div role="navigation" className="mobile-menu2">
                                <RaceQualifiers raceid={this.props.match.params.race} />
                            </div>

                            <div className="tabHeader">
                                <label htmlFor="mobile-menu-checkbox" id="mobile-menu-btn">
                                    <span className="menu-link"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default RaceDetails;